import axios from "axios";
import { useEffect, useState } from "react";

function ProductCrud() {

const [id, setId] = useState("");
const [pname, setName] = useState("");
const [pdescription, setDescription] = useState("");
const [pprice, setPrice] = useState("");
const [products, setProducts] = useState([]);
 
  useEffect(() => {
    (async () => await Load())();
  }, []);
 
  async function Load() {
    
    const result = await axios.get("https://localhost:7115/api/Product/GetProducts");
    setProducts(result.data);
    console.log(result.data);
  }
 
  async function save(event) {
   
    event.preventDefault();
    try {
      await axios.post("https://localhost:7115/api/Product/AddProduct", {
        
        pname: pname,
        pdescription: pdescription,
        pprice: pprice
       
      });
      alert("Product Added Successfully");
          setId("");
          setName("");
          setDescription("");
          setPrice("");
       
     
      Load();
    } catch (err) {
      alert(err);
    }
  }

  async function editProduct(products) {
    setName(products.pname);
    setDescription(products.pdescription);
    setPrice(products.pprice);
 
    setId(products.id);
  }
 

  async function DeleteProduct(id) {
  await axios.delete("https://localhost:7115/api/Product/DeleteProduct/" + id);
   alert("Product deleted Successfully");
   setId("");
   setName("");
   setDescription("");
   setPrice("");
   Load();
  }
 

  async function update(event) {
    event.preventDefault();
    try {

  await axios.patch("https://localhost:7115/api/Product/UpdateProduct/"+ products.find((u) => u.id === id).id || id,
        {
        id: id,
        pname: pname,
        pdescription: pdescription,
        pprice: pprice

        }
      );
      alert("Product Updated!");
      setId("");
      setName("");
      setDescription("");
      setPrice("");
     
      Load();
    } catch (err) {
      alert(err);
    }
  }

    return (
      <div>
        <h1>Product Details</h1>
      <div className="container mt-4">
        <form>
          <div className="form-group">
           
            <input
              type="text"
              className="form-control"
              id="id"
              hidden
              value={id}
              onChange={(event) => {
                setId(event.target.value);
              }}
            />
            </div>
            <div className="form-group">
            <label>Product Name</label>
            <input
              type="text"
              className="form-control"
              id="pname"
              value={pname}
              onChange={(event) => {
                setName(event.target.value);
              }}
            />
          </div>
          <div className="form-group">
            <label>Product Description</label>
            <input
              type="text"
              className="form-control"
              id="pdescription"
              value={pdescription}
              onChange={(event) => {
                setDescription(event.target.value);
              }}
            />
          </div>
          <div className="form-group">
            <label>Product Price</label>
            <input
              type="text"
              className="form-control"
              id="pprice"
              value={pprice}
              onChange={(event) => {
                setPrice(event.target.value);
              }}
            />
          </div>
          <div>
            <button className="btn btn-primary mt-4" onClick={save}>
              Register
            </button>
            <button className="btn btn-warning mt-4" onClick={update}>
              Update
            </button>
          </div>
        </form>
      </div>
      <br></br>

      <table className="table table-dark" align="center">
        <thead>
          <tr>
            <th scope="col">Product Id</th>
            <th scope="col">Product Name</th>
            <th scope="col">Description</th>
            <th scope="col">Price</th>
         
 
            <th scope="col">Option</th>
          </tr>
        </thead>
        {products.map(function fn(product) {
          return (
            <tbody>
              <tr>
                <th scope="row">{product.id} </th>
                <td>{product.pname}</td>
                <td>{product.pdescription}</td>
                <td>{product.pprice}</td>
                
                <td>
                  <button
                    type="button"
                    className="btn btn-warning"
                    onClick={() => editProduct(product)}
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => DeleteProduct(product.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            </tbody>
          );
        })}
      </table>
        
      </div>
    );
  };
  
  export default ProductCrud;