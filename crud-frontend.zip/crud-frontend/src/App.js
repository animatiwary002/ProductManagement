import ProductCrud from "./components/ProductCrud";

function App() {
  return (
    <div>
      <ProductCrud/>
    </div>
  );
};

export default App;
